import numpy as np 
import numdifftools as nd

def conjugue_grad(x0, func, n):
    x = x0
    I = np.eye(len(x))
    
    for k in range(n):
        xk = x
        dk = -nd.Gradient(func, method='forward')(xk)
        alphak = np.dot(dk.T, dk) / np.dot(dk.T, np.dot(I, dk))
        xkk = xk + alphak * dk
        grad_xkk = nd.Gradient(func, method='forward')(xkk)
        Betak = np.dot(grad_xkk.T, np.dot(I, dk)) / np.dot(dk.T, np.dot(I, dk))
        dkk = -grad_xkk + Betak * dk
        x = xkk  # Mise à jour de x après la mise à jour de dk
        dk = dkk
     
    return xk

def f(x):
    return 0.5 * (x[0]**2 + x[1]**2)

print(conjugue_grad(np.array([2, 1]), f, 10))
