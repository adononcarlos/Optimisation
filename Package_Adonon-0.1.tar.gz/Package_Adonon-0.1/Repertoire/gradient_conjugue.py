import numpy as np 

def conjugue_grad(x0,func,n):
    
    x=x0
    d0=-np.gradient(func(x0),x0)
    k=0
    I=np.eye(len(x))
    for k in range(1,n-1,1):
        xk=x0
        dk=-np.gradient(func(xk),xk)
        alphak= np.dot(dk.T,dk)/ np.dot(dk.T,np.dot(I,dk))
        xkk= xk + alphak*dk
        Betak= np.dot(np.gradient(func(xkk),xkk).T,np.dot(I,dk))/ np.dot(dk.T,np.dot(I,dk))
        dkk= -np.gradient(func(xkk),xkk) + Betak*dk
        xk=xkk
     
    return xk

def f(x):
    return 0.5*(x[0]**2 + x[1]**2)

print(conjugue_grad(np.array([2,1]),f,10))
        
        