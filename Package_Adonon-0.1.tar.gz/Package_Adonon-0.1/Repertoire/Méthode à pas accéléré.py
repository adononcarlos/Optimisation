import matplotlib.pyplot as plt
import numpy as np
from matplotlib.animation import FuncAnimation
from time import time
import math
import pylab



def f(x):
    return x*x*x

import matplotlib.pyplot as plt
import numpy as np
def accmeth(f,a,b,n):
    p=(b-a)/n
    x1=a
    x2= x1 + p
    while f(x1)>f(x2):
        p=p*2
        x1=x2
        x2=x1 + p
    
            
    return (x1+x2)/2

print(accmeth(f,0,1,1000))
    
X=np.linspace(0,accmeth(f,0,1,1000))
Y=[0 for x in X]
plt.scatter(X,Y)
plt.show()
    
    
       
    