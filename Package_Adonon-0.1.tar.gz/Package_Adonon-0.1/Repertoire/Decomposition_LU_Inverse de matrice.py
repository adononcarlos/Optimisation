import numpy as np
import scipy.linalg as sp

def invlu(A):
    try:
        #décomposition LU de la matrice d'abord
        P, L, U = sp.lu(A)
        #matrice identité de même taille que la matrice à inverser
        I = np.eye(len(A))
        #matrice inverse initialisée à vide
        X = []


        #on vérifie si la matrice est inversible
        if np.linalg.det(A) == 0:
            print("Matrice non inversible")
            return None

        else:
            #pour chaque colonne de l'identité
            for i in range(len(I)):
                   
                #on va résoudre L.Z1=C1 pour trouver Z1 sachant que C1 c'est la 1ère colonne de l'identité   
                Yi = np.zeros(len(U))
                for k in range(len(L)):
                    Yi[k] = (I[i][k] - np.dot(L[k, :k], Yi[:k])) / L[k][k]

                Zi = Yi
                

                #on va résoudre U.X1=Z1 pour avoir X1 sachant que X1 est la 1ère colonne de l'inverse de A
                Wi = np.zeros(len(Zi))
                for k in range(len(U) - 1, -1, -1):
                    Wi[k] = (Zi[k] - np.dot(U[k, k + 1:], Wi[k + 1:])) / U[k][k]

                Xi = Wi
                X.append(Xi)

        return X
    #écartes les autres cas qui ne nous intéressent pas
    except:
        print("Erreur lors de l'inversion de la matrice")
        return None

A = np.array([
    [25., 5, 1],
    [64, 8, 1],
    [144, 12, 1]
], dtype=float)

#affichage de la matrice
print("Matrice A:")
print(A)
resultat = invlu(A)

#affichage de l'inverse
if resultat is not None:
    print("Inverse de A:")
    print(resultat)
#on a maintenant l'inverse de la matrice
