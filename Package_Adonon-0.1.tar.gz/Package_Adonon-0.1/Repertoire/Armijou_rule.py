import numpy as np 
import numdifftools as nd

def f(x):
    return x**2 - 2*x + 1

def armijo(f, x, alpha=1.0, beta=0.5, c=0.01):
    direction = -nd.Gradient(f)(x)
    while f(x + alpha * direction) > (f(x) + c * alpha * np.dot(nd.Gradient(f)(x), direction)):
        alpha *= beta
    return alpha


print(armijo(f,0,1,0.785,0.01))