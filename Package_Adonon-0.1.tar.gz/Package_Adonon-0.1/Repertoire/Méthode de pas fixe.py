import matplotlib.pyplot as plt
import numpy as np
from time import time
def f(x):
    return x*(x-1.5)

def pasfix(f,a,b,n):
    p=(b-a)/n
    x=a
    
    while f(x)>f(x+p):
        
        x=x+p
        
    return float(x)
            
    
t1=time()
a=pasfix(f,0,1,1000)
t2=time()
print(a,t2-t1)
X=np.linspace(0,pasfix(f,0,1,1000))
Y=[0 for x in X]
plt.scatter(X,Y)
plt.show()
