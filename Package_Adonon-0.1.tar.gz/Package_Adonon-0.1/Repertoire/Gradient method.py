import numpy as np
from math import *
import numdifftools as nd

def g(x):
    return 0.5*(x[0]**2 + x[1]**2)

# Règle d'Armijo pour trouver le pas alpha
def armijo(f, x, alpha=1.0, beta=0.5, c=0.01):
    direction = -nd.Gradient(f)(x)
    while f(x + alpha * direction) > f(x) + c * alpha * np.dot(nd.Gradient(f)(x), direction):
        alpha *= beta
    return alpha

def gradie(g,x,eps):
    
    k=0
    xk=x
    
    
    while( np.linalg.norm(nd.Gradient(g)(xk))  >eps):
        alphak= armijo(g, x, alpha=1, beta=2, c=0.05)
        xkk= xk - alphak*nd.Gradient(g)(xk)
        xk = xkk
        k=k+1
   
    return xk
    
print(gradie(g,np.array([0,0]),0.01))

