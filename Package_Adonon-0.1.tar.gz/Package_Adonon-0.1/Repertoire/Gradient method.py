import numpy as np
from math import *

def g(x1,x2):
    return 0.5*(x1**2 + x2**2)
def fibo(n):
    if n==0 or n==1:
        return 1
    elif n>=2:
        return fibo(n-1) + fibo(n-2)
    
print(fibo(10))

def fibmet(f,a,b,eps):
    l=b-a
    def n_it(l,eps):
        n=0
        while (l/fibo(n))<=eps:
            n=n+1
        return n
    
    n= n_it(l,eps)    
    unitey=l/fibo(n)
    l2=fibo(n-2)*unitey
    x1= a+ l2
    x2= b+ l2
    
    while n>1:
        n=n-1
        if f(x1)<f(x2):
            b=x2
            x2=x1
            x1= a + (fibo(n-2))*unitey
            
        else:
            a=x1
            x1=x2
            x2 = b - fibo(n-2)*unitey
            
    return (a+b)/2

def phi(g,alpha,xk):
    return g(xk- alpha*np.gradient(g,xk))

def gradie(g,x,eps):
    
    k=0
    xk=x
    alpha=eps
    
    while( sqrt(sum(x**2 for x in np.gradient(g,xk)))>eps):
        alphak= min(fibmet(phi(g,alpha,xk),0,10,eps)) 
        xkk= xk - alphak*np.gradient(g,xk)
        xk = xkk
        k=k+1
    x=xk
    return x
    
print(gradie(g,1,0.01))
