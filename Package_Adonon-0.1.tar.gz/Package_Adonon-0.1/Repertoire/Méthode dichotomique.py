import matplotlib.pyplot as plt
import numpy as np
def f(x):
    return x*(x-1.5)

def dicho(f,a,b,d,eps):
    print("*****")
    while (b-a)>eps:
       m=(a+b)/2
       l=m-d
       r=m+d
       if f(l)>f(r):
           a=l
       elif f(l)<f(r):
           b=r
       else:
           break
    return (a+b)/2     


       
print(dicho(f,0,1,0.01,0.0000001))
X=np.linspace(0,dicho(f,0,1,0.01,0.0000001))
Y=[0 for x in X]
plt.scatter(X,Y)
plt.show()