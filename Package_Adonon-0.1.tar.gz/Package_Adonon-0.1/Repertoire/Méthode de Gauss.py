import numpy as np
import scipy as sp

def invlu(A):
    D= sp.linalg.lu(A)
    L=D[1]
    U=D[2]
    I=np.eye(len(A))
    
    X=[]
    
    if np.linalg.det(A)==0:
        print("Matrice non inversible")
        
    else:
        for i in range (0,len(I),1):
            Ci=[ligne[i] for ligne in I]
            Z=np.linalg.solve(L,Ci)
            Xi=np.linalg.solve(U,Z)
            X[len(I)-i+1]=Xi
            
        return X
            
A=[
    [25,5,1],
    [64,8,1],
    [144,12,1]
]

print(A)
print(invlu(A))
B=invlu(A)
print(np.linalg.inv(A))



    #on va résoudre L.Z1=C1 pour trouver Z1 sachant que C1 c'est la 1ère colonne de l'identité
    
    
    
    
    #on va résoudre U.X1=Z1 pour avoir X1 sachant que X1 est la 1ère colonne de l'inverse de A
   
   