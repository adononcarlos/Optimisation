

def f(x):
    return x*(x-1.5)

def fibo(n):
    if n==0 or n==1:
        return 1
    elif n>=2:
        return fibo(n-1) + fibo(n-2)
    
print(fibo(10))

def fibmet(f,a,b,eps):
    l=b-a
    def n_it(l,eps):
        n=0
        while (l/fibo(n))<=eps:
            n=n+1
        return n
    
    n= n_it(l,eps)    
    unitey=l/fibo(n)
    l2=fibo(n-2)*unitey
    x1= a+ l2
    x2= b+ l2
    
    while n>1:
        n=n-1
        if f(x1)<f(x2):
            b=x2
            x2=x1
            x1= a + (fibo(n-2))*unitey
            
        else:
            a=x1
            x1=x2
            x2 = b - fibo(n-2)*unitey
            
    return (a+b)/2

print(fibmet(f,0,9,0.0001))