import numpy as np 
import numdifftools as nd 
import scipy as sp

def g(x):
    return x[0] - x[1] + 2*x[0]**2 + 2*x[0]*x[1] + x[1]**2



def armijo(f, x, alpha=1.0, beta=0.5, c=0.01):
    direction = -nd.Gradient(f)(x)
    while f(x + alpha * direction) > f(x) + c * alpha * np.dot(nd.Gradient(f)(x), direction):
        alpha *= beta
    return alpha


def DFP(x0, eps, f):
    k = 0
    xk = x0
    Hk = np.eye(len(x0))  # Matrice Hessienne initiale, ici une matrice identité
    grad_f = nd.Gradient(f)(xk)

    while np.linalg.norm(grad_f) > eps:
        dk = -np.dot(Hk, grad_f.T)  # Direction de recherche

        # Minimisation le long de la direction dk
        alpha_k = armijo(f, xk, alpha=1.0, beta=0.5, c=0.01)
        
        xkk = xk + alpha_k * dk
        grad_fkk = nd.Gradient(f)(xkk)
        
        #on va appliquer DFP pour Hkk
        yk = grad_fkk - grad_f
        Hkyk = np.dot(Hk, yk)
        Hk +=  ((alpha_k*np.outer(dk,dk.T)) / np.dot(dk.T,yk) ) - (np.outer(Hkyk,Hkyk.T) / np.dot(yk.T,Hkyk))
        xk = xkk
        grad_f = grad_fkk
        k += 1

    return xk


   
print(DFP(np.array([1,1]),0.1,g))   
    
        
       
   