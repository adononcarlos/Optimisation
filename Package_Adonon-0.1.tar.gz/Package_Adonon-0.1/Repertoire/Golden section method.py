import matplotlib.pyplot as plt
import numpy as np

def f(x):
    return x*(x-1.5)

def gold(f,a,b,e):
    x1=a
    x4=b
    x2= x1 + (1-2/(1+5**0.5))*(x4-x1)
    x3=b - (1-2/(1+5**0.5))*(x4-x1)
    while x4-x1>e:
        if f(x1)>f(x2) and f(x2)>=f(x3):
            x1=x2
            x2=x3
            x3=x4- (1-2/(1+5**0.5))*(x4-x1)
            
        else:
            if f(x2)<=f(x3) and f(x3)<f(x4):
                x4=x3
                x3=x2
                x2=x1 + (1-2/(1+5**0.5))*(x4-x1)
                
    return (x4 + x1)/2

print(gold(f,0,9,0.001))
X=np.linspace(0,gold(f,0,1,0.001))
Y=[0 for x in X]
plt.scatter(X,Y)
plt.show()