import matplotlib.pyplot as plt
import numpy as np
def f(x):
    return x*(x-1.5)

def hal(f,a,b,eps):
    
    x0=(b+a)/2
    while(b-a)>eps:
        
        x1=(a+x0)/2
        x2=(b+x0)/2
        if f(x1) < f(x0) and f(x0) < f(x2):
            b,x0=x0,x1
            
        if f(x1)>f(x0) and f(x0) > f(x2):
            a,x0=x0,x2
            
        if f(x0) < f(x1) and f(x0) < f(x2):
            a,b=x1,x2
            
        else:
            break
    
    return (a+b)/2
        
print(hal(f,0,1,0.000001))

X=np.linspace(0,hal(f,0,1,0.000001))
Y=[0 for x in X]
plt.scatter(X,Y)
plt.show()


    