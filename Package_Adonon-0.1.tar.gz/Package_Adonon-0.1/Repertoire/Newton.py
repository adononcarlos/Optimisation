import numpy as np 
import numdifftools as nd 
import scipy as sp

def f(x):
    return x**2 + 2*x + 1

def f_prim(x):
    deriv = 2*x +2
    return deriv

def f_second(x):
    deriv2 = 2
    return deriv2
    
    
def Newton(f,x,eps):
    
    ecart= eps
    x1 = x - f_prim(x)/f_second(x)
    if np.linalg.norm(np.abs(f_prim(x1)))>eps: 
        x2= x1 - f_prim(x1)/f_second(x1)
        xk=x2
        while np.linalg.norm(np.abs(f_prim(xk)))>eps: 
            
            xk = xk - f_prim(xk)/f_second(xk)
        
        return xk
    
    
    
print(Newton(f,2,0.01))