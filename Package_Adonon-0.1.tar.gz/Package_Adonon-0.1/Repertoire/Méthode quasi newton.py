import numpy as np 
import numdifftools as nd 
import scipy as sp

def f(x):
    return x**2 + 2*x +1

def derivative(func,x,h=1e-6):
    return (func(x+h)- func(x))/h

def phi(g,alpha,xk):
    return g(xk- alpha*np.gradient(g,xk))

def armijo(alpha0,mu,eps):
    alpha=alpha0
    
    if phi(alpha)<= phi(0) + eps*derivative(phi,0)*alpha:
        while phi(mu*alpha)< phi(0) + eps* derivative(phi,0)*mu*alpha :
            alpha=mu*alpha
          
        return alpha
    
    else:
        while phi(alpha)> phi(0) + eps*derivative(phi,0)*alpha:
            alpha= alpha/mu
        return alpha


import numpy as np
import numdifftools as nd

def DFP(x0, eps, f):
    k = 0
    xk = x0
    Hk = np.eye(len(x0))  # Matrice Hessienne initiale, ici une matrice identité
    grad_f = np.gradient(lambda x: f(x), xk)

    while np.linalg.norm(grad_f) > eps:
        dk = -np.dot(Hk, grad_f)  # Direction de recherche

        # Minimisation le long de la direction dk
        alpha_k = min(fibo(lambda alpha: f(xk + alpha * dk), 0, 10, eps))
        
        xkk = xk + alpha_k * dk
        grad_fkk = np.gradient(lambda x: f(x), xkk)
        
        sk = xkk - xk
        yk = grad_fkk - grad_f
        
        # Mise à jour de la matrice Hessian inverse
        Hyk = np.dot(Hk, yk)
        Hk += np.outer(sk, sk) / np.dot(yk, sk) - np.outer(Hyk, Hyk) / np.dot(yk, Hyk)

        xk = xkk
        grad_f = grad_fkk
        k += 1

    return xk

# Exemple d'utilisation avec une fonction quadratique
def quadratic_function(x):
    return np.sum(x**2)

# Conditions initiales
initial_point = np.array([1.0, 0.5])
epsilon = 1e-6

# Appel de la fonction DFP
result = DFP(initial_point, epsilon, quadratic_function)

print("Résultat de DFP :", result)
   
        
    
        
       
   