import numpy as np 
import numdifftools as nd 
import scipy as sp

def f(x):
    return x**2 + 2*x + 1

def f_prim(x,ecart):
    deriv = (f(x+ecart) - f(x-ecart))/ (2* ecart)
    return deriv

def f_second(x,ecart):
    deriv2 = (f(x+ecart) + f(x-ecart) - 2*f(x)) / (ecart**2)
    return deriv2
    
    
def quasi(f,x,eps):
    
    ecart= eps
    x1 = x - f_prim(x,ecart)/f_second(x,ecart)
    if np.linalg.norm(np.abs(f_prim(x1,ecart)))>eps: 
        x2= x1 - f_prim(x1,ecart)/f_second(x1,ecart)
        xk=x2
        while np.linalg.norm(np.abs(f_prim(xk,ecart)))>eps: 
            
            xk = xk - f_prim(xk,ecart)/f_second(xk,ecart)
        
        return xk
    
    
    
print(quasi(f,2,0.01))
    
        