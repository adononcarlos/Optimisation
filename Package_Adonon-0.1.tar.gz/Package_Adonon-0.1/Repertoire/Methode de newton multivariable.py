import numpy  as np
import numdifftools as nd
from math import *




def g(x):
    return 0.5*np.sum(x**2)

def fibo(n):
    if n==0 or n==1:
        return 1
    elif n>=2:
        return fibo(n-1) + fibo(n-2)
    


def fibmet(f,a,b,eps):
    l=b-a
    def n_it(l,eps):
        n=0
        while (l/fibo(n))<=eps:
            n=n+1
        return n
    
    n= n_it(l,eps)    
    unitey=l/fibo(n)
    l2=fibo(n-2)*unitey
    x1= a+ l2
    x2= b+ l2
    
    while n>1:
        n=n-1
        if f(x1)<f(x2):
            b=x2
            x2=x1
            x1= a + (fibo(n-2))*unitey
            
        else:
            a=x1
            x1=x2
            x2 = b - fibo(n-2)*unitey
            
    return (a+b)/2

def phi(g,alpha,xk):
    return g(xk- alpha*np.gradient(g,xk))


def new(x,eps,g):
    
    k=0
    xk=x
    alpha=eps
    H=nd.Hessian(g)
    d0= -(np.linalg.inv(H(xk)))@ np.gradient(g,xk)
    dk=d0 
    
    
    
    while((sqrt(sum(x**2 for x in dk)))>eps):
        alphak= min(fibmet(phi(g,alpha,xk),0,10,eps))
        
        xkk= xk+ alphak @ dk
        
        values=np.linalg.eigvals(H(xkk))
        
        if  all(val >0 for val in values)   >0 :
                              
            dkk= -(np.linalg.inv(H(xkk)) @ np.gradient(g,xkk))
            dk=dkk 
            
        else:
            dk= -np.linalg.inv(eps*np.eye(len(xk))+ H(xk)) @ np.gradient(g,xk)
        k=k+1
            
    x=xk
    return xk
        
    
    
print(new(np.array[1,0.01],0.01,g))