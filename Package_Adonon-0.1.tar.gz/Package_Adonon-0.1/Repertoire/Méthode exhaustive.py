import matplotlib.pyplot as plt
import numpy as np

def fun(x):
    return x*(x-1.5)

def exhaus(fun,a,b,n):
    cmp=0
    p=(b-a)/n
    Min=fun(a)
    for i in range (1,n+1):
        y=fun(a+i*p)
        if Min>y:
            Min=y
            cmp+=1
            
    return a+(cmp+1)*p


print(exhaus(fun,0,1,100))
            
X=np.linspace(0,exhaus(fun,0,1,100))
Y=[0 for x in X]
plt.scatter(X,Y)
plt.show() 