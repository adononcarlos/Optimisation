from setuptools import setup, find_packages

setup(
    name='Package_Adonon',
    version='0.1',
    packages=find_packages(),
    author='ADONON',
    author_email='adononcarlos@gmail.com',
    description='Package contenant les fichiers python des implémentations vues au cours en optimisation au premier semestre',
    
)
